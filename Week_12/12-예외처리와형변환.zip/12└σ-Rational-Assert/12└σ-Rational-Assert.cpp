#include "Rational.h"

void main() 
{
	Rational r;
	cout << "r �Է�(a/b): ";
	cin >> r;
	cout << "r = " << r << " = " << r.real() << endl;
}
