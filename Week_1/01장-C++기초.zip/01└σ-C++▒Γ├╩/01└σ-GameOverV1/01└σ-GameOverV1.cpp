// GameOverMain.cpp
#include <stdio.h>

void main()
{
	printf("Game Over !\n");
}