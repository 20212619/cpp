#include "Shape.h"
void main()
{
	Point p(1, 2);
}