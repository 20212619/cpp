#include "Shape.h"
Point p(1, 2);
void main()
{
}