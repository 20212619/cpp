double Celcius2Fahrenheit(double cels);
double Fahrenheit2Celcius(double fahr);
int playUpAndDown(int n, int min, int max);
void printNumPyramid(int height);