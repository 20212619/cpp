#include "FifteenPuzzle.h"
void main()
{
	FifteenPuzzle game;
	game.play("ranking.txt");
}